from .funciones import media
__all__ = ['media']

# Make the media function available directly
__version__ = '0.1.0'
media = media  # This makes the function available at the package level


