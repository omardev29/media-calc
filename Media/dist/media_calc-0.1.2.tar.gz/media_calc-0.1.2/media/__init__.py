from .funciones import media

__all__ = ['media']


